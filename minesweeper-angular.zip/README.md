# minesweeper-angular

The popular minesweeper game has come to web from your desktop. Clone the project, run the server and browse http://localhost:4000.
You are good to play the game.

steps to run the game : 

Make sure you have node, npm installed and available from command line.

1. Unzip the file.
2. "cd" to the application directory from command prompt.
3. run the command "npm install" without quotes.
4. "cd" to the server folder in application directory.
5. run the command "node server" without quotes.
6. go to browser, and hit url "http://localhost:4000"
7. you will see your game running in the browser.
8. you have one more tab to read through the rules of the game if you are new.
